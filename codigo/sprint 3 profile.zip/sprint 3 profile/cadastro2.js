var users = [];

var storedUsers = localStorage.getItem("users");
if (storedUsers) {
  users = JSON.parse(storedUsers);
}

document.getElementById("registerForm").addEventListener("submit", function(event) {
  event.preventDefault(); 

  var newUsername = document.getElementById("newUsername").value;
  var newPassword = document.getElementById("newPassword").value;

  if (newUsername !== "" && newPassword !== "") {
    var existingUser = users.find(function(user) {
      return user.username === newUsername;
    });

    if (existingUser) {
      alert("Usuário já existe. Escolha um nome de usuário diferente.");
    } else {
      var newUser = {
        username: newUsername,
        password: newPassword
      };

      users.push(newUser);
      alert("Cadastro realizado com sucesso! Agora você pode fazer login com seu novo usuário.");

      localStorage.setItem("users", JSON.stringify(users));

      window.location.href = "login.html";
    }
  } else {
    alert("Por favor, preencha todos os campos.");
  }
});
