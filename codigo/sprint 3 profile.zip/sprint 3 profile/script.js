
var users = [];

var storedUsers = localStorage.getItem("users");
if (storedUsers) {
  users = JSON.parse(storedUsers);
}

function registerUser(username, password) {
  var existingUser = users.find(function(user) {
    return user.username === username;
  });

  if (existingUser) {
    alert("Usuário já existe. Escolha um nome de usuário diferente.");
  } else {
    var newUser = {
      username: username,
      password: password
    };

    users.push(newUser);
    alert("Cadastro realizado com sucesso! Agora você pode fazer login com seu novo usuário.");

    localStorage.setItem("users", JSON.stringify(users));
    window.location.href = "index.html";
  }
}

function loginUser(username, password) {
  var user = users.find(function(user) {
    return user.username === username && user.password === password;
  });

  if (user) {
    alert("Login bem-sucedido!");
    localStorage.setItem("currentUser", JSON.stringify(user));
    window.location.href = "profile.html";
  } else {
    alert("Usuário ou senha inválidos. Tente novamente.");
  }
}

function logoutUser() {
  localStorage.removeItem("currentUser");
  window.location.href = "login.html";
}

document.getElementById("loginForm").addEventListener("submit", function(event) {
  event.preventDefault();
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  loginUser(username, password);
});

document.getElementById("logoutButton").addEventListener("click", function(event) {
  event.preventDefault();
  logoutUser();
});
